#define _INTEGRAL_MAX_BITS 64
#define _MSC_VER 1800
#define _MSC_FULL_VER 180021005
#define _MSC_BUILD 1
#define _M_AMD64 100
#define _M_X64 100
#define _WIN64 
#define _WIN32 
#define _MT 
#define _DLL 
#define _CPPRTTI 
